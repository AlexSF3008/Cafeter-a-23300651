const formulario = document.querySelector(".formulario");
const botonLimpiar = document.getElementById("btn-limpiar");

botonLimpiar.addEventListener("click", function () {
    if (confirm("¿Desea limpiar?")) {
        formulario.reset();
    }
});

formulario.addEventListener("submit", function (evento) {
    const nombre = document.getElementById("nombre").value.trim();
    const producto = document.getElementById("producto").value;
    const correo = document.getElementById("correo").value.trim();
    const cantidad = Number(document.getElementById("cantidad").value);
    const tamano = document.querySelector('input[name="tamano"]:checked');

    const correoValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo);
    const cantidadValida = Number.isInteger(cantidad) && cantidad >= 1;

    if (nombre === "" || producto === "" || !correoValido || !cantidadValida || tamano === null) {
        evento.preventDefault();
        alert("Datos inválidos");
        return;
    }

    alert("Pedido registrado correctamente");
    setTimeout(function () {
        formulario.reset();
    }, 0);
});