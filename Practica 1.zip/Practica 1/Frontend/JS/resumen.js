const parametros = new URLSearchParams(window.location.search);

const campos = ["cliente", "producto", "tamano", "cantidad", "correo", "llevar", "observaciones"];

campos.forEach(function (campo) {
    const elemento = document.getElementById("r-" + campo);
    elemento.textContent = parametros.get(campo) || "—";
});