const db = require('../config/database');

async function registrarPedido(cliente, producto, tamano, correo, cantidad, llevar, observaciones) {
    const sql = `
        INSERT INTO pedidos (cliente, producto, tamano, correo, cantidad, llevar, observaciones)
        VALUES (?,?,?,?,?,?,?)`;

    const [resultado] = await db.execute(sql, [
        cliente,
        producto,
        tamano,
        correo,
        cantidad,
        llevar,
        observaciones
    ]);
    return resultado.insertId;
}

async function obtenerPedido(id) {
    const sql = `SELECT * FROM pedidos WHERE id = ?`;

    const [filas] = await db.execute(sql, [id]);
    return filas[0];
}

module.exports = { registrarPedido, obtenerPedido };