const pedidoModel = require('../Models/pedidoModel');

async function registrarPedido(req, res){
    try{
        const { cliente, producto, tamano, correo } = req.body;
        const cantidad = Number(req.body.cantidad);
        const llevar = req.body.llevar === 'on';
        const observaciones = req.body.observaciones || '';

        if(typeof cliente !== 'string' ||
            !cliente.trim() ||
            typeof producto !== 'string' ||
            !producto.trim() ||
            typeof tamano !== 'string' ||
            !tamano.trim() ||
            typeof correo !== 'string' ||
            !correo.trim() ||
            !Number.isInteger(cantidad) ||
            cantidad < 1 ||
            typeof observaciones !== 'string'){
            return res.status(400).send('Datos del pedido son inválidos');
        }

        await pedidoModel.registrarPedido(
            cliente.trim(),
            producto.trim(),
            tamano.trim(),
            correo.trim(),
            cantidad,
            llevar,
            observaciones.trim()
        );

        const parametros = new URLSearchParams({
            cliente: cliente.trim(),
            producto: producto.trim(),
            tamano: tamano.trim(),
            correo: correo.trim(),
            cantidad: cantidad,
            llevar: llevar ? 'Sí' : 'No',
            observaciones: observaciones.trim() || 'Ninguna'
        });

     res.redirect('/HTML/resumen.html?' + parametros.toString());
    } catch (error){
        console.error('Error al registrar pedido:', error);
        res.status(500).send('Error al guardar el pedido');
    }
}

module.exports = {
    registrarPedido
};