const express = require('express');
const path = require('path');

const pedidoRoutes = require('./routes/pedidoRoutes');

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../Frontend')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../Frontend/HTML/index.html'));
});

app.use('/', pedidoRoutes);

app.listen(3000, () => {
    console.log('Servidor ejecutandose en el puerto 3000');
});